﻿// Напишите программу, которая принимает на вход цифру,
// обозначающую день недели, и проверяет, является ли
// этот день выходным.
System.Console.Write("Введите номер дня недели  ");
int day = Convert.ToInt32(Console.ReadLine());

if(day==6 || day==7)
{
    System.Console.WriteLine("Holyday");
}

if (day > 7)
{
    System.Console.WriteLine("Wrong number");
}

else if (day <=5)
{
    System.Console.WriteLine("Work, honey, work...");
}