﻿// Напишите программу, которая выводит третью цифру заданного
// числа или сообщает, что третьей цифры нет.

System.Console.Write("Введите число  ");
string? number = Console.ReadLine();

if (number! .Length >= 3)
{
    System.Console.WriteLine (number [2]);
}

else
{
    System.Console.WriteLine ("Введено неверное число");
}
